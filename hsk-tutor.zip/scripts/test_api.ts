import { GoogleGenAI } from '@google/genai';

async function test() {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: 'Say hello',
    });
    console.log('API works:', response.text);
  } catch (e) {
    console.error('API failed:', e);
  }
}
test();
