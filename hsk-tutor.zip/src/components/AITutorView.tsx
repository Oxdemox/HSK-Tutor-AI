import React, { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Send, Loader2, Bot, User, Sparkles } from 'lucide-react';
import { GoogleGenAI, Type } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import HskDropdown, { HSKLevel } from './HskDropdown';

type Message = {
  id: string;
  role: 'user' | 'model';
  text: string;
};

type Props = {
  hskLevel: string;
  onHskLevelChange: (level: HSKLevel) => void;
  onBack: () => void;
};

export default function AITutorView({ hskLevel, onHskLevelChange, onBack }: Props) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: "Hello! I'm your AI Chinese Tutor. You can ask me anything about HSK vocabulary, grammar points, or Chinese culture. How can I help you today?"
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const chat = ai.chats.create({
        model: "gemini-3-flash-preview",
        config: {
          systemInstruction: `You are an expert Chinese language tutor specializing in the HSK (Hanyu Shuiping Kaoshi) curriculum. 
Your current focus is teaching ${hskLevel} Mandarin Chinese.
Provide clear explanations of grammar, vocabulary usage, and cultural context. 
Use a supportive, encouraging tone. 
When explaining Chinese words or sentences, always provide the Hanzi, Pinyin, and English translation. 
Keep explanations concise but thorough.`,
        }
      });

      // Send the whole history for context
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          ...history,
          { role: 'user', parts: [{ text: input }] }
        ],
        config: {
          systemInstruction: `You are an expert Chinese language tutor specializing in the HSK (Hanyu Shuiping Kaoshi) curriculum. 
Your current focus is teaching ${hskLevel} Mandarin Chinese.
Provide clear explanations of grammar, vocabulary usage, and cultural context. 
Use a supportive, encouraging tone. 
When explaining Chinese words or sentences, always provide the Hanzi, Pinyin, and English translation. 
Keep explanations concise but thorough.`,
        }
      });

      const modelMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text || "I'm sorry, I couldn't generate a response. Please try again."
      };

      setMessages(prev => [...prev, modelMessage]);
    } catch (error) {
      console.error("AI Tutor Error:", error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: "Sorry, I encountered an error. Please check your connection and try again."
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-stone-900 font-sans flex flex-col h-screen">
      <header className="bg-white border-b border-stone-200 py-4 px-6 shadow-sm z-10">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="p-2 -ml-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-full transition-colors"
            >
              <ArrowLeft size={24} />
            </button>
            <div className="flex items-center gap-2">
              <Sparkles className="text-red-500" size={20} />
              <h1 className="text-xl font-bold text-stone-800 tracking-tight">AI HSK Tutor</h1>
            </div>
          </div>
          <HskDropdown 
            value={hskLevel}
            onChange={onHskLevelChange}
          />
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-3xl mx-auto space-y-6">
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  msg.role === 'user' ? 'bg-stone-800 text-white' : 'bg-red-100 text-red-600'
                }`}>
                  {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                </div>
                <div className={`p-4 rounded-2xl shadow-sm border ${
                  msg.role === 'user' 
                    ? 'bg-stone-900 text-white border-stone-800' 
                    : 'bg-white text-stone-800 border-stone-200'
                }`}>
                  <div className="markdown-body prose prose-sm max-w-none">
                    <ReactMarkdown>{msg.text}</ReactMarkdown>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex gap-3 max-w-[85%]">
                <div className="w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
                  <Bot size={16} />
                </div>
                <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-center gap-2">
                  <Loader2 size={16} className="animate-spin text-stone-400" />
                  <span className="text-stone-400 text-sm font-medium">Tutor is thinking...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      <footer className="bg-white border-t border-stone-200 p-4 md:p-6">
        <div className="max-w-3xl mx-auto">
          <div className="relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about grammar, words, or HSK levels..."
              className="w-full p-4 pr-14 rounded-2xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-3 bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={20} />
            </button>
          </div>
          <p className="text-[10px] text-stone-400 mt-3 text-center uppercase tracking-widest font-bold">
            Powered by Gemini AI • HSK Expert Mode
          </p>
        </div>
      </footer>
    </div>
  );
}
