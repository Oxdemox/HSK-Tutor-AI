import React, { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Mic, MicOff, Languages, Volume2, Loader2, RefreshCw } from 'lucide-react';
import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';
import { AudioRecorder, AudioPlayer } from '../utils/audio';

type Props = {
  onBack: () => void;
};

type TranscriptMessage = {
  id: string;
  role: 'user' | 'model';
  english: string;
  chinese: string;
  pinyin?: string;
};

export default function TranslationView({ onBack }: Props) {
  const [activeTab, setActiveTab] = useState<'voice' | 'text'>('voice');
  
  // Voice state
  const [isLiveConnected, setIsLiveConnected] = useState(false);
  const [isLiveConnecting, setIsLiveConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);
  const [messages, setMessages] = useState<TranscriptMessage[]>([]);
  
  // Text state
  const [textInput, setTextInput] = useState('');
  const [textOutput, setTextOutput] = useState('');
  const [textPinyin, setTextPinyin] = useState('');
  const [isTranslatingText, setIsTranslatingText] = useState(false);
  
  const audioRecorderRef = useRef<AudioRecorder | null>(null);
  const audioPlayerRef = useRef<AudioPlayer | null>(null);
  const sessionRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      disconnectLive();
    };
  }, []);

  const connectLive = async () => {
    setIsLiveConnecting(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      audioPlayerRef.current = new AudioPlayer((isPlaying) => {
        setIsModelSpeaking(isPlaying);
      });
      
      const sessionPromise = ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-12-2025",
        callbacks: {
          onopen: () => {
            setIsLiveConnected(true);
            setIsLiveConnecting(false);
            
            audioRecorderRef.current = new AudioRecorder(
              (base64Data) => {
                sessionPromise.then((session: any) => {
                  session.sendRealtimeInput({
                    media: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
                  });
                });
              },
              (volume, speaking) => {
                setIsUserSpeaking(speaking);
              }
            );
            
            audioRecorderRef.current.start();
          },
          onmessage: async (message: LiveServerMessage) => {
            console.log("Live API Message:", message);
            if (message.serverContent?.interrupted) {
              audioPlayerRef.current?.stop();
              setIsModelSpeaking(false);
              return;
            }

            if (message.toolCall?.functionCalls) {
              const responses = message.toolCall.functionCalls.map(call => {
                if (call.name === 'display_translation') {
                  const args = call.args as any;
                  if (args.chinese || args.english) {
                    setMessages(prev => [...prev, { 
                      id: Date.now().toString(), 
                      role: 'model', 
                      english: args.english || '', 
                      chinese: args.chinese || '', 
                      pinyin: args.pinyin 
                    }]);
                  }
                  
                  return {
                    ...(call.id ? { id: call.id } : {}),
                    name: call.name,
                    response: { output: { result: "displayed" } }
                  };
                }
                return null;
              }).filter(Boolean);

              if (responses.length > 0) {
                sessionPromise.then((session: any) => {
                  session.sendToolResponse({
                    functionResponses: responses
                  });
                });
              }
            }

            if (message.serverContent?.modelTurn) {
              const parts = message.serverContent.modelTurn.parts;
              for (const part of parts) {
                if (part.inlineData && part.inlineData.data) {
                  audioPlayerRef.current?.play(part.inlineData.data);
                }
                if (part.text) {
                  console.log("Model Text Output:", part.text);
                }
              }
            }
          },
          onclose: () => {
            disconnectLive();
          },
          onerror: (err) => {
            console.error("Live API Error:", err);
            setError("Connection error occurred. Please try again.");
            disconnectLive();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction: "You are a voice translator. Translate English to Chinese and Chinese to English. Speak the translation. Also call 'display_translation' with the English and Chinese text.",
          tools: [{
            functionDeclarations: [{
              name: "display_translation",
              description: "Show translation text.",
              parameters: {
                type: Type.OBJECT,
                properties: {
                  english: { type: Type.STRING },
                  chinese: { type: Type.STRING },
                  pinyin: { type: Type.STRING }
                },
                required: ["english", "chinese"]
              }
            }]
          }]
        }
      });
      
      sessionRef.current = sessionPromise;
      
    } catch (err) {
      console.error("Error connecting to Live API:", err);
      setError("Failed to connect to the translation service.");
      setIsLiveConnecting(false);
    }
  };

  const disconnectLive = () => {
    if (audioRecorderRef.current) {
      audioRecorderRef.current.stop();
      audioRecorderRef.current = null;
    }
    if (audioPlayerRef.current) {
      audioPlayerRef.current.stop();
      audioPlayerRef.current = null;
    }
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => session.close()).catch(console.error);
      sessionRef.current = null;
    }
    setIsLiveConnected(false);
    setIsLiveConnecting(false);
    setIsModelSpeaking(false);
    setIsUserSpeaking(false);
  };

  const handleTextTranslation = async () => {
    if (!textInput.trim()) return;
    setIsTranslatingText(true);
    setTextOutput('');
    setTextPinyin('');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Translate the following text. Provide both the English and Mandarin Chinese (Hanzi) versions, and the pinyin for the Chinese text. Provide the result in JSON format: { "english": "...", "chinese": "...", "pinyin": "..." }. Text: "${textInput}"`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              english: { type: Type.STRING },
              chinese: { type: Type.STRING },
              pinyin: { type: Type.STRING }
            },
            required: ["english", "chinese"]
          }
        }
      });
      
      const result = JSON.parse(response.text);
      setTextOutput(result.chinese || result.english); // Default display
      setTextPinyin(result.pinyin || '');
      
      // Add to history
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        english: result.english,
        chinese: result.chinese,
        pinyin: result.pinyin
      }]);
    } catch (err) {
      console.error("Text translation error:", err);
      setTextOutput("Translation failed. Please try again.");
    } finally {
      setIsTranslatingText(false);
    }
  };

  const playTranslation = (text: string, isChinese: boolean) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = isChinese ? 'zh-CN' : 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-stone-900 font-sans flex flex-col">
      <header className="bg-white border-b border-stone-200 py-4 px-6 shadow-sm z-10">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 -ml-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-stone-800 tracking-tight">Translator</h1>
        </div>
      </header>

      <main className="flex-1 max-w-3xl w-full mx-auto p-6 flex flex-col gap-6">
        {/* Tabs */}
        <div className="flex p-1 bg-stone-200/50 rounded-xl mb-2">
          <button
            onClick={() => setActiveTab('voice')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-bold transition-all ${
              activeTab === 'voice' 
                ? 'bg-white text-stone-900 shadow-sm' 
                : 'text-stone-500 hover:text-stone-700'
            }`}
          >
            Voice Translator
          </button>
          <button
            onClick={() => setActiveTab('text')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-bold transition-all ${
              activeTab === 'text' 
                ? 'bg-white text-stone-900 shadow-sm' 
                : 'text-stone-500 hover:text-stone-700'
            }`}
          >
            Text Translator
          </button>
        </div>

        {activeTab === 'voice' ? (
          <>
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 text-center">
              <div className="flex items-center justify-center gap-3 mb-6 text-stone-800">
                <Languages size={32} className="text-red-500" />
                <h2 className="text-2xl font-bold">English ↔ Chinese</h2>
              </div>
              
              <p className="text-stone-500 mb-8 max-w-md mx-auto">
                Speak naturally in either English or Chinese. The translator will automatically detect the language and speak the translation back to you.
              </p>
              
              <div className="flex justify-center mb-6">
                <button
                  onClick={isLiveConnected ? disconnectLive : connectLive}
                  disabled={isLiveConnecting}
                  className={`relative group flex items-center justify-center w-32 h-32 rounded-full transition-all duration-300 shadow-lg ${
                    isLiveConnected 
                      ? 'bg-red-50 text-red-500 hover:bg-red-100' 
                      : 'bg-stone-900 text-white hover:bg-stone-800 hover:scale-105'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {isLiveConnecting ? (
                    <Loader2 size={40} className="animate-spin" />
                  ) : isLiveConnected ? (
                    <MicOff size={40} />
                  ) : (
                    <Mic size={40} />
                  )}
                  
                  {/* Ripple effect when active */}
                  {isLiveConnected && (
                    <>
                      <div className="absolute inset-0 rounded-full border-2 border-red-500 animate-ping opacity-20"></div>
                      <div className="absolute -inset-4 rounded-full border border-red-500 animate-ping opacity-10" style={{ animationDelay: '0.5s' }}></div>
                    </>
                  )}
                </button>
              </div>
              
              <div className="h-8 flex items-center justify-center">
                {isLiveConnecting && <span className="text-stone-500 font-medium animate-pulse">Connecting to translator...</span>}
                {isLiveConnected && !isUserSpeaking && !isModelSpeaking && <span className="text-emerald-600 font-medium">Listening...</span>}
                {isUserSpeaking && <span className="text-red-500 font-medium animate-pulse">You are speaking...</span>}
                {isModelSpeaking && <span className="text-blue-500 font-medium animate-pulse">Translating...</span>}
              </div>

              {error && (
                <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-xl text-sm border border-red-100">
                  {error}
                </div>
              )}
            </div>

            {messages.length > 0 && (
              <div className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 flex-1 overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-stone-400 uppercase tracking-wider">Translation History</h3>
                  <button 
                    onClick={() => setMessages([])}
                    className="text-[10px] font-bold text-red-500 uppercase tracking-widest hover:text-red-700"
                  >
                    Clear History
                  </button>
                </div>
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div key={msg.id} className="p-4 rounded-2xl bg-stone-50 border border-stone-100 flex flex-col gap-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="text-xs font-bold text-stone-400 mb-1 uppercase tracking-wider">English</div>
                          <div className="text-lg text-stone-800 whitespace-pre-wrap leading-tight">{msg.english}</div>
                        </div>
                        <button 
                          onClick={() => playTranslation(msg.english, false)}
                          className="p-2 bg-white text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg border border-stone-200 transition-all shadow-sm shrink-0"
                          title="Listen to English"
                        >
                          <Volume2 size={16} />
                        </button>
                      </div>
                      
                      <div className="h-px bg-stone-200/50 w-full"></div>
                      
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="text-xs font-bold text-stone-400 mb-1 uppercase tracking-wider">Chinese</div>
                          <div className="text-lg text-stone-800 whitespace-pre-wrap leading-tight">{msg.chinese}</div>
                          {msg.pinyin && (
                            <div className="text-sm text-stone-500 mt-1 font-medium">{msg.pinyin}</div>
                          )}
                        </div>
                        <button 
                          onClick={() => playTranslation(msg.chinese, true)}
                          className="p-2 bg-white text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg border border-stone-200 transition-all shadow-sm shrink-0"
                          title="Listen to Chinese"
                        >
                          <Volume2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 flex flex-col gap-4">
            <div className="flex items-center gap-3 text-stone-800 mb-2">
              <Languages size={24} className="text-red-500" />
              <h2 className="text-xl font-bold">Text Translator</h2>
            </div>
            
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="Enter English or Chinese text here..."
              className="w-full h-32 p-4 rounded-2xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 resize-none"
            />
            
            <button
              onClick={handleTextTranslation}
              disabled={isTranslatingText || !textInput.trim()}
              className="w-full py-3 bg-stone-900 text-white rounded-xl font-bold hover:bg-stone-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isTranslatingText ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  Translating...
                </>
              ) : (
                'Translate'
              )}
            </button>
            
            {(textOutput || isTranslatingText) && (
              <div className="mt-4 p-4 rounded-2xl bg-stone-50 border border-stone-200 min-h-[8rem]">
                <div className="text-sm font-bold text-stone-400 mb-2 uppercase tracking-wider">Translation</div>
                {isTranslatingText ? (
                  <div className="flex items-center justify-center h-full text-stone-400">
                    <Loader2 size={24} className="animate-spin" />
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="text-xs font-bold text-stone-400 mb-1 uppercase tracking-wider">English</div>
                        <div className="text-lg text-stone-800 whitespace-pre-wrap">{messages[messages.length - 1]?.english || ''}</div>
                      </div>
                      <button 
                        onClick={() => playTranslation(messages[messages.length - 1]?.english || '', false)}
                        className="p-2 bg-white text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg border border-stone-200 transition-all shadow-sm shrink-0"
                      >
                        <Volume2 size={16} />
                      </button>
                    </div>
                    
                    <div className="h-px bg-stone-200/50 w-full"></div>
                    
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="text-xs font-bold text-stone-400 mb-1 uppercase tracking-wider">Chinese</div>
                        <div className="text-lg text-stone-800 whitespace-pre-wrap">{messages[messages.length - 1]?.chinese || ''}</div>
                        {messages[messages.length - 1]?.pinyin && (
                          <div className="text-sm text-stone-500 mt-1">{messages[messages.length - 1]?.pinyin}</div>
                        )}
                      </div>
                      <button 
                        onClick={() => playTranslation(messages[messages.length - 1]?.chinese || '', true)}
                        className="p-2 bg-white text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg border border-stone-200 transition-all shadow-sm shrink-0"
                      >
                        <Volume2 size={16} />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
