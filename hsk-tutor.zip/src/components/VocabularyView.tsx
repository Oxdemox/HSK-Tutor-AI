import React, { useState, useEffect } from 'react';
import { ArrowLeft, Volume2, Star, StarOff, Filter } from 'lucide-react';
import { hskVocabulary, HSKLevel } from '../data/hsk';
import HskDropdown from './HskDropdown';
import { auth, db } from '../firebase';
import { collection, doc, setDoc, deleteDoc, onSnapshot, query } from 'firebase/firestore';

type Props = {
  onBack: () => void;
};

export default function VocabularyView({ onBack }: Props) {
  const [activeLevel, setActiveLevel] = useState<HSKLevel>('HSK 1');
  const [starredWords, setStarredWords] = useState<Set<string>>(new Set());
  const [showStarredOnly, setShowStarredOnly] = useState(false);

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(collection(db, 'users', auth.currentUser.uid, 'starred_words'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const starred = new Set<string>();
      snapshot.forEach((doc) => {
        starred.add(doc.id);
      });
      setStarredWords(starred);
    });

    return () => unsubscribe();
  }, []);

  const toggleStar = async (wordId: string) => {
    if (!auth.currentUser) return;

    const wordRef = doc(db, 'users', auth.currentUser.uid, 'starred_words', wordId);
    if (starredWords.has(wordId)) {
      await deleteDoc(wordRef);
    } else {
      await setDoc(wordRef, {
        wordId,
        timestamp: new Date()
      });
    }
  };

  const filteredVocab = hskVocabulary.filter(v => 
    v.level === activeLevel && (!showStarredOnly || starredWords.has(v.id))
  );

  // Group by lesson
  const groupedVocab = filteredVocab.reduce((acc, item) => {
    if (!acc[item.lesson]) {
      acc[item.lesson] = [];
    }
    acc[item.lesson].push(item);
    return acc;
  }, {} as Record<number, typeof filteredVocab>);

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-stone-900 font-sans flex flex-col">
      <header className="bg-white border-b border-stone-200 py-4 px-6 shadow-sm z-10">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="p-2 -ml-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-full transition-colors"
            >
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-xl font-bold text-stone-800 tracking-tight">Vocabulary List</h1>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowStarredOnly(!showStarredOnly)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-all ${
                showStarredOnly 
                  ? 'bg-amber-100 text-amber-600 border border-amber-200' 
                  : 'bg-stone-100 text-stone-600 border border-stone-200 hover:bg-stone-200'
              }`}
            >
              <Star size={16} fill={showStarredOnly ? "currentColor" : "none"} />
              <span>Starred</span>
            </button>
            <HskDropdown 
              value={activeLevel}
              onChange={(val) => setActiveLevel(val as HSKLevel)}
            />
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto p-6 flex flex-col gap-6">
        {/* Vocabulary content */}

        <div className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 space-y-8">
          {Object.entries(groupedVocab).map(([lesson, items]) => (
            <div key={lesson} className="border-b border-stone-100 pb-8 last:border-0 last:pb-0">
              <h2 className="text-xl font-bold text-stone-800 mb-4">Lesson {lesson}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {items.map((item) => {
                  const num = item.id.split('-')[1];
                  return (
                    <div key={item.id} className="flex items-center justify-between p-4 rounded-2xl border border-stone-100 bg-stone-50 hover:bg-stone-100 transition-colors">
                      <div className="flex items-start gap-4">
                        <span className="text-stone-400 font-mono text-sm mt-1">{num}.</span>
                        <div>
                          <div className="flex items-baseline gap-3 mb-1">
                            <span className="text-2xl font-bold text-stone-800">{item.hanzi}</span>
                            <span className="text-sm text-stone-500 font-medium">{item.pinyin}</span>
                          </div>
                          <p className="text-stone-600">{item.english}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          className={`p-2 rounded-full transition-colors ${
                            starredWords.has(item.id) 
                              ? 'text-amber-500 bg-amber-50' 
                              : 'text-stone-300 hover:text-amber-500 hover:bg-amber-50'
                          }`}
                          onClick={() => toggleStar(item.id)}
                        >
                          <Star size={20} fill={starredWords.has(item.id) ? "currentColor" : "none"} />
                        </button>
                        <button 
                          className="p-2 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                          onClick={() => {
                            window.speechSynthesis.cancel();
                            const utterance = new SpeechSynthesisUtterance(item.hanzi);
                            utterance.lang = 'zh-CN';
                            window.speechSynthesis.speak(utterance);
                          }}
                        >
                          <Volume2 size={20} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
