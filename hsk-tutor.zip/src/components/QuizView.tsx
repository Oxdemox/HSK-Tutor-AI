import React, { useState, useEffect } from 'react';
import { ArrowLeft, CheckCircle2, XCircle, RefreshCw, Volume2 } from 'lucide-react';
import { hskVocabulary, HSKLevel, VocabularyItem } from '../data/hsk';
import HskDropdown from './HskDropdown';
import { db } from '../firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { User as FirebaseUser } from 'firebase/auth';

type Props = {
  user: FirebaseUser | null;
  onBack: () => void;
};

type QuestionType = 'reading' | 'listening' | 'pinyin';

type QuizQuestion = {
  item: VocabularyItem;
  type: QuestionType;
  options: string[];
};

export default function QuizView({ user, onBack }: Props) {
  const [activeLevel, setActiveLevel] = useState<HSKLevel>('HSK 1');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);

  useEffect(() => {
    startQuiz(activeLevel);
  }, [activeLevel]);

  useEffect(() => {
    if (questions.length > 0 && questions[currentIndex] && questions[currentIndex].type === 'listening') {
      const timer = setTimeout(() => {
        playAudio(questions[currentIndex].item.hanzi);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [currentIndex, questions]);

  const generateOptions = (correctItem: VocabularyItem, allVocab: VocabularyItem[], type: QuestionType): string[] => {
    const wrongItems = allVocab
      .filter(v => v.id !== correctItem.id)
      .sort(() => 0.5 - Math.random())
      .slice(0, 3);
    
    let options: string[] = [];
    if (type === 'reading') {
      options = [...wrongItems.map(v => v.english), correctItem.english];
    } else {
      // For listening and pinyin, options are Hanzi
      options = [...wrongItems.map(v => v.hanzi), correctItem.hanzi];
    }
    
    return options.sort(() => 0.5 - Math.random());
  };

  const startQuiz = (level: HSKLevel) => {
    const vocab = hskVocabulary.filter(v => v.level === level);
    // Shuffle and pick all questions for the level
    const shuffled = [...vocab].sort(() => 0.5 - Math.random());
    
    const generatedQuestions: QuizQuestion[] = shuffled.map(item => {
      const types: QuestionType[] = ['reading', 'listening', 'pinyin'];
      const type = types[Math.floor(Math.random() * types.length)];
      return {
        item,
        type,
        options: generateOptions(item, vocab, type)
      };
    });

    setQuestions(generatedQuestions);
    setCurrentIndex(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
  };

  const playAudio = (text: string) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'zh-CN';
    window.speechSynthesis.speak(utterance);
  };

  const handleAnswer = (answer: string) => {
    if (selectedAnswer) return; // Prevent multiple clicks
    
    setSelectedAnswer(answer);
    const currentQ = questions[currentIndex];
    const isCorrect = 
      (currentQ.type === 'reading' && answer === currentQ.item.english) ||
      (currentQ.type !== 'reading' && answer === currentQ.item.hanzi);
    
    const newScore = score + (isCorrect ? 1 : 0);
    if (isCorrect) {
      setScore(newScore);
    }

    setTimeout(() => {
      if (currentIndex < questions.length - 1) {
        setCurrentIndex(i => i + 1);
        setSelectedAnswer(null);
      } else {
        setShowResult(true);
        saveProgress(activeLevel, newScore, questions.length);
      }
    }, 1500);
  };

  const saveProgress = async (level: string, correct: number, total: number) => {
    if (!user) return;

    try {
      const progressRef = doc(db, 'users', user.uid, 'quiz_progress', level);
      const progressDoc = await getDoc(progressRef);
      
      let data = {
        quizScore: 0,
        totalQuizzes: 0,
        sentenceScore: 0,
        totalSentences: 0
      };

      if (progressDoc.exists()) {
        data = progressDoc.data() as any;
      }

      await setDoc(progressRef, {
        ...data,
        quizScore: (data.quizScore || 0) + correct,
        totalQuizzes: (data.totalQuizzes || 0) + total,
        lastUpdated: serverTimestamp()
      }, { merge: true });
    } catch (err) {
      console.error("Error saving quiz progress to Firestore:", err);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-stone-900 font-sans flex flex-col">
      <header className="bg-white border-b border-stone-200 py-4 px-6 shadow-sm z-10">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="p-2 -ml-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-full transition-colors"
            >
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-xl font-bold text-stone-800 tracking-tight">Vocabulary Quiz</h1>
          </div>
          <HskDropdown 
            value={activeLevel}
            onChange={(val) => setActiveLevel(val as HSKLevel)}
          />
        </div>
      </header>

      <main className="flex-1 max-w-2xl w-full mx-auto p-6 flex flex-col justify-center">
        {questions.length === 0 ? (
          <div className="text-center text-stone-500">Loading questions...</div>
        ) : showResult ? (
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 text-center">
            <div className="bg-emerald-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm border border-emerald-200">
              <span className="text-4xl font-bold text-emerald-600">{score}/{questions.length}</span>
            </div>
            <h2 className="text-2xl font-bold text-stone-800 mb-2">Quiz Complete!</h2>
            <p className="text-stone-500 mb-8">Great job practicing your {activeLevel} vocabulary.</p>
            
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => startQuiz(activeLevel)}
                className="w-full bg-red-600 text-white font-bold py-4 px-6 rounded-2xl shadow-lg shadow-red-600/20 hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
              >
                <RefreshCw size={20} />
                Try Again
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200">
            <div className="flex justify-between items-center mb-8">
              <span className="text-sm font-bold text-stone-400 uppercase tracking-wider">Question {currentIndex + 1} of {questions.length}</span>
              <span className="text-sm font-bold text-red-500 uppercase tracking-wider">Score: {score}</span>
            </div>

            <div className="text-center mb-10 min-h-[120px] flex flex-col items-center justify-center">
              {questions[currentIndex].type === 'reading' && (
                <>
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <h2 className="text-6xl font-bold text-stone-800">{questions[currentIndex].item.hanzi}</h2>
                    <button 
                      onClick={() => playAudio(questions[currentIndex].item.hanzi)}
                      className="p-3 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                      title="Play pronunciation"
                    >
                      <Volume2 size={32} />
                    </button>
                  </div>
                  <p className="text-2xl text-stone-500 font-medium">{questions[currentIndex].item.pinyin}</p>
                </>
              )}
              {questions[currentIndex].type === 'pinyin' && (
                <>
                  <p className="text-sm font-bold text-stone-400 uppercase tracking-wider mb-4">Choose the correct characters for:</p>
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <h2 className="text-5xl font-bold text-stone-800">{questions[currentIndex].item.pinyin}</h2>
                    <button 
                      onClick={() => playAudio(questions[currentIndex].item.hanzi)}
                      className="p-3 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                      title="Play pronunciation"
                    >
                      <Volume2 size={32} />
                    </button>
                  </div>
                </>
              )}
              {questions[currentIndex].type === 'listening' && (
                <>
                  <p className="text-sm font-bold text-stone-400 uppercase tracking-wider mb-6">Listen and choose the correct characters:</p>
                  <button 
                    onClick={() => playAudio(questions[currentIndex].item.hanzi)}
                    className="w-24 h-24 bg-red-50 text-red-600 rounded-full flex items-center justify-center hover:bg-red-100 transition-colors shadow-sm border border-red-100 mb-4"
                  >
                    <Volume2 size={40} />
                  </button>
                </>
              )}
            </div>

            <div className="space-y-3">
              {questions[currentIndex].options.map((option, idx) => {
                const currentQ = questions[currentIndex];
                const isCorrect = 
                  (currentQ.type === 'reading' && option === currentQ.item.english) ||
                  (currentQ.type !== 'reading' && option === currentQ.item.hanzi);
                const isSelected = option === selectedAnswer;
                
                let buttonClass = "w-full p-4 rounded-2xl border-2 text-left font-medium text-lg transition-all ";
                
                if (!selectedAnswer) {
                  buttonClass += "border-stone-200 bg-white hover:border-red-500 hover:bg-red-50 text-stone-700";
                } else if (isCorrect) {
                  buttonClass += "border-emerald-500 bg-emerald-50 text-emerald-700";
                } else if (isSelected && !isCorrect) {
                  buttonClass += "border-red-500 bg-red-50 text-red-700";
                } else {
                  buttonClass += "border-stone-200 bg-stone-50 text-stone-400 opacity-50";
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleAnswer(option)}
                    disabled={!!selectedAnswer}
                    className={buttonClass}
                  >
                    <div className="flex items-center justify-between">
                      <span className={currentQ.type !== 'reading' ? 'text-2xl font-bold' : ''}>{option}</span>
                      {selectedAnswer && isCorrect && <CheckCircle2 className="text-emerald-500" />}
                      {selectedAnswer && isSelected && !isCorrect && <XCircle className="text-red-500" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
