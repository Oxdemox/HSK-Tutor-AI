import React, { useState, useEffect } from 'react';
import { ArrowLeft, User, Mail, Save, Trash2, Loader2, AlertCircle, CheckCircle2, Image as ImageIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { auth, db } from '../firebase';
import { doc, getDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { deleteUser, User as FirebaseUser } from 'firebase/auth';

type Props = {
  user: FirebaseUser;
  onBack: () => void;
};

export default function ProfileView({ user, onBack }: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setName(data.name || '');
          setEmail(data.email || user.email || '');
        } else {
          setEmail(user.email || '');
        }
      } catch (err) {
        console.error("Error loading profile:", err);
        setMessage({ type: 'error', text: 'Failed to load profile data.' });
      } finally {
        setIsLoading(false);
      }
    };
    loadProfile();
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setMessage(null);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        name
      });
      setMessage({ type: 'success', text: 'Profile updated successfully.' });
    } catch (err: any) {
      console.error("Error updating profile:", err);
      setMessage({ type: 'error', text: err.message || 'Failed to update profile.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!window.confirm("Are you sure you want to delete your account? This action cannot be undone and all your data will be lost.")) {
      return;
    }
    
    setIsDeleting(true);
    setMessage(null);
    try {
      // Delete user document from Firestore
      await deleteDoc(doc(db, 'users', user.uid));
      // Delete user from Auth
      await deleteUser(user);
      // Auth state listener in App.tsx will handle the redirect to login
    } catch (err: any) {
      console.error("Error deleting account:", err);
      if (err.code === 'auth/requires-recent-login') {
        setMessage({ type: 'error', text: 'Please log out and log back in to delete your account.' });
      } else {
        setMessage({ type: 'error', text: err.message || 'Failed to delete account.' });
      }
      setIsDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f5f5f0] flex items-center justify-center">
        <Loader2 size={40} className="animate-spin text-red-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-stone-900 font-sans flex flex-col h-screen">
      <header className="bg-white border-b border-stone-200 py-4 px-6 shadow-sm z-10">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 -ml-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div className="flex items-center gap-2">
            <User className="text-red-500" size={20} />
            <h1 className="text-xl font-bold text-stone-800 tracking-tight">My Profile</h1>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-[2rem] shadow-sm border border-stone-200 p-6 md:p-8">
            
            {message && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`mb-6 p-4 rounded-2xl text-sm flex items-start gap-3 ${
                  message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-red-50 text-red-700 border border-red-100'
                }`}
              >
                {message.type === 'success' ? <CheckCircle2 size={18} className="shrink-0 mt-0.5" /> : <AlertCircle size={18} className="shrink-0 mt-0.5" />}
                <p className="font-medium">{message.text}</p>
              </motion.div>
            )}

            <form onSubmit={handleSave} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <input 
                    type="email"
                    disabled
                    value={email}
                    className="w-full bg-stone-100 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none text-stone-500 font-medium cursor-not-allowed"
                  />
                </div>
                <p className="text-xs text-stone-400 ml-1">Email cannot be changed.</p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <input 
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your Name"
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                  />
                </div>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isSaving}
                  type="submit"
                  className="flex-1 bg-stone-900 text-white rounded-2xl py-3.5 font-bold shadow-lg shadow-stone-900/10 hover:bg-stone-800 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                  <span>Save Changes</span>
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isDeleting}
                  type="button"
                  onClick={handleDeleteAccount}
                  className="sm:w-auto px-6 bg-red-50 text-red-600 rounded-2xl py-3.5 font-bold hover:bg-red-100 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isDeleting ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} />}
                  <span>Delete Account</span>
                </motion.button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}
