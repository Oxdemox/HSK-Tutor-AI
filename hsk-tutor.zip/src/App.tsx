import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';
import { Mic, MicOff, Loader2, Volume2, MessageSquare, BookOpen, Activity, ArrowLeft, ChevronRight, HelpCircle, Languages, RefreshCw, Sparkles, Trophy, LogIn, User, Shield, LogOut, Key, Mail, AlertCircle, CheckCircle2, Pencil } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AudioRecorder, AudioPlayer } from './utils/audio';
import { auth, db } from './firebase';
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, User as FirebaseUser, sendPasswordResetEmail } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import VocabularyView from './components/VocabularyView';
import ProgressView from './components/ProgressView';
import QuizView from './components/QuizView';
import TranslationView from './components/TranslationView';
import GrammarView from './components/GrammarView';
import SentenceBuilderView from './components/SentenceBuilderView';
import AITutorView from './components/AITutorView';
import FlashcardsView from './components/FlashcardsView';
import HskDropdown from './components/HskDropdown';
import ProfileView from './components/ProfileView';
import CurriculumView from './components/CurriculumView';
import CharacterWritingView from './components/CharacterWritingView';
import ReadingView from './components/ReadingView';
import PinyinChartView from './components/PinyinChartView';
import { Lesson } from './data/curriculum';

const MandarinLogo = ({ size = 40, className = "" }: { size?: number, className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 100 100" 
    fill="currentColor" 
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <text 
      x="50" 
      y="52" 
      fontSize="46" 
      fontFamily="'Noto Serif SC', 'STKaiti', 'KaiTi', serif" 
      fontWeight="bold" 
      textAnchor="middle" 
      dominantBaseline="central"
      letterSpacing="2"
    >
      中文
    </text>
  </svg>
);

const getSystemInstruction = (level: string, lesson?: Lesson | null) => `You are an intelligent, highly interactive Chinese language learning voice assistant. 
Your current focus is teaching ${level} Mandarin Chinese.${lesson ? `\n\nSpecifically, this session is focused on the lesson: "${lesson.title}".\nDescription: ${lesson.description}\n\nKey Vocabulary to practice:\n${lesson.vocabulary.map(v => `- ${v.word} (${v.pinyin}): ${v.translation}`).join('\n')}\n\nKey Grammar to practice:\n${lesson.grammar.map(g => `- ${g.title}: ${g.explanation}`).join('\n')}` : ''}

CRITICAL RULES FOR INTERACTION:
1. KEEP RESPONSES VERY SHORT AND CONCISE. (1 to 2 sentences maximum).
2. ALWAYS end your turn by asking a relevant follow-up question based on the user's previous response to keep the conversation going.
3. Speak naturally, conversationally, and at a moderate pace.
4. Encourage the user to provide longer, more detailed inputs in both Chinese and English. If they give a short answer, ask them to elaborate.
5. YOU MUST SPEAK IN ENGLISH ONLY. ALL of your spoken audio responses MUST be in English. Do NOT speak Chinese characters.
6. If the user makes a mistake, quickly and politely correct them in English, then move on.
7. Adapt your teaching strictly to the ${level} level.
8. You MUST call the 'display_transcript' tool BEFORE you speak to show what the user said and what you are about to say in English, Chinese, and Pinyin. The 'tutor_chinese' and 'tutor_pinyin' fields in the tool call should contain the Chinese translation of your English response, even though you will only speak the English part.
9. DO NOT repeat yourself. If the user asks a new question, answer it. If the user changes the subject, follow their lead.

Roles:
- Tutor: Teach vocabulary, pronunciation (pinyin), and grammar for ${level}.
- Practice Partner: Engage in real-life roleplay (greetings, ordering food, directions, etc.).
- Translator: Translate between English and Chinese if asked.
- Pronunciation Coach: If asked to practice pronunciation, provide a word or short phrase, ask the user to repeat it, and then give specific, actionable feedback on their tones (e.g., "Your first tone was a bit low, try to keep it high and flat") and pronunciation (e.g., "Make sure to curl your tongue back for the 'zh' sound"). Point out exactly which syllable had the wrong tone or sound.

Remember: Be highly interactive, fast-paced, and concise. Do not give long monologues or detailed explanations unless explicitly asked.`;

type Message = {
  id: string;
  role: 'user' | 'model';
  text: string;
  structured?: {
    english?: string;
    chinese?: string;
    pinyin?: string;
  };
};

type ViewState = 'menu' | 'lesson' | 'vocabulary' | 'progress' | 'quiz' | 'translation' | 'grammar' | 'sentence-builder' | 'ai-tutor' | 'flashcards' | 'profile' | 'curriculum' | 'writing' | 'reading' | 'pinyin-chart';

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userRole, setUserRole] = useState<'admin' | 'user' | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const [isRegistering, setIsRegistering] = useState(false);
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRepeatPassword, setRegRepeatPassword] = useState('');
  const [regError, setRegError] = useState<string | null>(null);
  const [isRegisteringUser, setIsRegisteringUser] = useState(false);

  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetMessage, setResetMessage] = useState<string | null>(null);
  const [resetError, setResetError] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  const [currentView, setCurrentView] = useState<ViewState>('menu');
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);

  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);
  const [hskLevel, setHskLevel] = useState<'HSK 1' | 'HSK 2' | 'HSK 3' | 'HSK 4' | 'HSK 5' | 'HSK 6'>('HSK 1');
  const [progressPercentage, setProgressPercentage] = useState(0);
  
  const sessionRef = useRef<any>(null);
  const recorderRef = useRef<AudioRecorder | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        // Fetch user role from Firestore
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            setUserRole(userDoc.data().role);
          } else {
            // If user exists in Auth but not in Firestore, they might be the default admin
            // or a new user that needs a profile.
            if (firebaseUser.email === "yassine.kheder.1994@gmail.com") {
              setUserRole('admin');
              // Create the admin profile if it doesn't exist
              await setDoc(doc(db, 'users', firebaseUser.uid), {
                uid: firebaseUser.uid,
                email: firebaseUser.email,
                name: firebaseUser.displayName || '',
                role: 'admin',
                createdAt: serverTimestamp()
              });
            } else {
              setUserRole('user');
              // Create the user profile if it doesn't exist
              await setDoc(doc(db, 'users', firebaseUser.uid), {
                uid: firebaseUser.uid,
                email: firebaseUser.email,
                name: firebaseUser.displayName || '',
                role: 'user',
                createdAt: serverTimestamp()
              });
            }
          }
        } catch (err) {
          console.error("Error fetching user role:", err);
        }
      } else {
        setUser(null);
        setUserRole(null);
      }
      setIsAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);
    try {
      await signInWithEmailAndPassword(auth, loginEmail, loginPassword);
    } catch (err: any) {
      console.error("Login error:", err);
      setLoginError("Password or Email Incorrect");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    
    if (regPassword !== regRepeatPassword) {
      setRegError("Passwords do not match");
      return;
    }

    setIsRegisteringUser(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, regEmail, regPassword);
      const newUser = userCredential.user;
      
      await setDoc(doc(db, 'users', newUser.uid), {
        uid: newUser.uid,
        email: regEmail,
        name: regName,
        role: regEmail === "yassine.kheder.1994@gmail.com" ? 'admin' : 'user',
        createdAt: serverTimestamp()
      });
    } catch (err: any) {
      console.error("Registration error:", err);
      if (err.code === 'auth/email-already-in-use') {
        setRegError("User already exists. Sign in ");
      } else {
        setRegError(err.message || "An error occurred during registration.");
      }
    } finally {
      setIsRegisteringUser(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetMessage(null);
    setIsResetting(true);
    try {
      await sendPasswordResetEmail(auth, resetEmail);
      setResetMessage(`We sent you a password change link to ${resetEmail}`);
    } catch (err: any) {
      console.error("Reset password error:", err);
      setResetError(err.message || "An error occurred.");
    } finally {
      setIsResetting(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentView('menu');
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  useEffect(() => {
    if (!user) return;

    const loadData = async () => {
      try {
        // Load History
        const historyDoc = await getDoc(doc(db, 'users', user.uid, 'history', hskLevel));
        if (historyDoc.exists()) {
          setMessages(historyDoc.data().messages || []);
        } else {
          setMessages([]);
        }

        // Load Progress
        const progressDoc = await getDoc(doc(db, 'users', user.uid, 'progress', hskLevel));
        if (progressDoc.exists()) {
          setProgressPercentage(progressDoc.data().percentage || 0);
        } else {
          setProgressPercentage(0);
        }
      } catch (err) {
        console.error("Error loading user data from Firestore:", err);
      }
    };

    loadData();
  }, [hskLevel, user]);

  useEffect(() => {
    if (!user || messages.length === 0) return;

    const saveData = async () => {
      try {
        await setDoc(doc(db, 'users', user.uid, 'history', hskLevel), {
          messages,
          lastUpdated: serverTimestamp()
        }, { merge: true });

        // Simple progress calculation: 5% per message, max 100%
        const newProgress = Math.min(100, messages.length * 5);
        if (newProgress !== progressPercentage) {
          setProgressPercentage(newProgress);
          await setDoc(doc(db, 'users', user.uid, 'progress', hskLevel), {
            hskLevel,
            percentage: newProgress,
            lastUpdated: serverTimestamp()
          }, { merge: true });
        }
      } catch (err) {
        console.error("Error saving user data to Firestore:", err);
      }
    };

    const timeoutId = setTimeout(saveData, 2000); // Debounce saves
    return () => clearTimeout(timeoutId);
  }, [messages, hskLevel, user]);

  const clearHistory = async () => {
    setMessages([]);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid, 'history', hskLevel), {
          messages: [],
          lastUpdated: serverTimestamp()
        }, { merge: true });
        
        setProgressPercentage(0);
        await setDoc(doc(db, 'users', user.uid, 'progress', hskLevel), {
          hskLevel,
          percentage: 0,
          lastUpdated: serverTimestamp()
        }, { merge: true });
      } catch (err) {
        console.error("Error clearing history in Firestore:", err);
      }
    }
    if (isConnected || isConnecting) {
      disconnect();
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (currentView === 'lesson') {
      scrollToBottom();
    }
  }, [messages, currentView]);

  const connect = async () => {
    if (isConnected || isConnecting) return;
    
    setIsConnecting(true);
    setError(null);
    try {
      if (!process.env.GEMINI_API_KEY) {
        throw new Error("Gemini API Key is missing. Please configure it in the Secrets panel.");
      }

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      // Initialize player and recorder during user gesture
      playerRef.current = new AudioPlayer((isPlaying) => {
        setIsModelSpeaking(isPlaying);
      });

      recorderRef.current = new AudioRecorder(
        (base64Data) => {
          if (sessionRef.current) {
            sessionRef.current.then((session: any) => {
              if (session) {
                session.sendRealtimeInput({
                  audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
                });
              }
            }).catch(err => console.error("Error sending audio:", err));
          }
        },
        (volume, speaking) => {
          setIsUserSpeaking(speaking);
        }
      );
      
      const historyText = messages.map(m => `${m.role === 'user' ? 'User' : 'Tutor'}: ${m.text}`).join('\n');
      const systemInstruction = getSystemInstruction(hskLevel, selectedLesson) + (historyText ? `\n\nHere is the transcript of our conversation so far. Please continue the conversation naturally from where we left off:\n${historyText}` : '');

      const sessionPromise = ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-12-2025",
        callbacks: {
          onopen: () => {
            setIsConnected(true);
            setIsConnecting(false);
            
            if (recorderRef.current) {
              recorderRef.current.start().catch(err => {
                console.error("Recorder start error:", err);
                setError("Could not access microphone. Please check permissions.");
                disconnect();
              });
            }
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle audio output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && playerRef.current) {
              playerRef.current.play(base64Audio);
            }
            
            // Handle interruption
            if (message.serverContent?.interrupted && playerRef.current) {
              playerRef.current.stop();
            }
            
            // Extract model transcription
            const modelParts = message.serverContent?.modelTurn?.parts;
            if (modelParts) {
              const text = modelParts.find(p => p.text)?.text;
              if (text) {
                setMessages(prev => {
                  const last = prev[prev.length - 1];
                  if (last && last.role === 'model') {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { ...last, text: last.text + text };
                    return newMessages;
                  }
                  return [...prev, { id: Date.now().toString(), role: 'model', text }];
                });
              }
            }
            
            // Handle tool calls
            if (message.toolCall?.functionCalls) {
              const responses = message.toolCall.functionCalls.map(call => {
                if (call.name === 'display_transcript') {
                  const args = call.args as any;
                  
                  if (args.user_english || args.user_chinese || args.user_pinyin) {
                    setMessages(prev => [...prev, {
                      id: Date.now().toString() + '-user',
                      role: 'user',
                      text: `[You]\nEnglish: ${args.user_english || ''}\nChinese: ${args.user_chinese || ''}\nPinyin: ${args.user_pinyin || ''}`,
                      structured: {
                        english: args.user_english,
                        chinese: args.user_chinese,
                        pinyin: args.user_pinyin
                      }
                    }]);
                  }
                  
                  if (args.tutor_english || args.tutor_chinese || args.tutor_pinyin) {
                    setMessages(prev => [...prev, {
                      id: Date.now().toString() + '-model',
                      role: 'model',
                      text: `[Tutor]\nEnglish: ${args.tutor_english || ''}\nChinese: ${args.tutor_chinese || ''}\nPinyin: ${args.tutor_pinyin || ''}`,
                      structured: {
                        english: args.tutor_english,
                        chinese: args.tutor_chinese,
                        pinyin: args.tutor_pinyin
                      }
                    }]);
                  }
                  
                  return {
                    id: call.id,
                    name: call.name,
                    response: { output: { result: "displayed" } }
                  };
                }
                return null;
              }).filter(Boolean);

              if (responses.length > 0) {
                sessionPromise.then((session: any) => {
                  session.sendToolResponse({
                    functionResponses: responses
                  });
                });
              }
            }
          },
          onclose: () => {
            disconnect();
          },
          onerror: (err) => {
            console.error("Live API Error:", err);
            setError("Connection error occurred. Please try again.");
            disconnect();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction: systemInstruction,
          tools: [{
            functionDeclarations: [{
              name: "display_transcript",
              description: "Display the transcript of what the user said and what the tutor is about to say, in English, Chinese, and Pinyin.",
              parameters: {
                type: Type.OBJECT,
                properties: {
                  user_english: { type: Type.STRING, description: "English translation of what the user said" },
                  user_chinese: { type: Type.STRING, description: "Chinese characters of what the user said" },
                  user_pinyin: { type: Type.STRING, description: "Pinyin of what the user said" },
                  tutor_english: { type: Type.STRING, description: "English translation of what the tutor is about to say" },
                  tutor_chinese: { type: Type.STRING, description: "Chinese characters of what the tutor is about to say" },
                  tutor_pinyin: { type: Type.STRING, description: "Pinyin of what the tutor is about to say" },
                },
                required: ["user_english", "user_chinese", "user_pinyin", "tutor_english", "tutor_chinese", "tutor_pinyin"]
              }
            }]
          }],
        },
      });
      
      sessionRef.current = sessionPromise;
      
    } catch (err: any) {
      console.error("Failed to connect:", err);
      setError(err.message || "Failed to connect to the assistant.");
      setIsConnecting(false);
    }
  };

  const disconnect = () => {
    if (recorderRef.current) {
      recorderRef.current.stop();
      recorderRef.current = null;
    }
    if (playerRef.current) {
      playerRef.current.stop();
      playerRef.current = null;
    }
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => session.close()).catch(() => {});
      sessionRef.current = null;
    }
    setIsConnected(false);
    setIsConnecting(false);
    setIsModelSpeaking(false);
    setIsUserSpeaking(false);
  };

  const toggleConnection = () => {
    if (isConnected || isConnecting) {
      disconnect();
    } else {
      connect();
    }
  };

  const requestTranslation = () => {
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => {
        session.sendClientContent({
          turns: [{
            role: 'user',
            parts: [{ text: 'Please act as a translator for my next sentence. If I speak English, translate it to Chinese. If I speak Chinese, translate it to English. Just provide the translation and nothing else.' }]
          }],
          turnComplete: true
        });
        
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', text: '(Requested Translation Mode for next phrase)' }]);
      });
    }
  };

  const requestPronunciationPractice = () => {
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => {
        session.sendClientContent({
          turns: [{
            role: 'user',
            parts: [{ text: `I want to practice pronunciation of new ${hskLevel} vocabulary. Please give me a word to repeat, and then provide feedback on my pronunciation.` }]
          }],
          turnComplete: true
        });
        
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', text: '(Requested Pronunciation Practice)' }]);
      });
    }
  };

  const handleStartLessonFromCurriculum = (lesson: Lesson) => {
    setSelectedLesson(lesson);
    setCurrentView('lesson');
  };

  const handleBackToMenu = () => {
    if (isConnected || isConnecting) {
      disconnect();
    }
    setCurrentView('menu');
  };

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#f5f5f0] flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="text-red-600"
        >
          <Loader2 size={40} />
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#f5f5f0] flex items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl border border-stone-200 p-8 sm:p-10 relative overflow-hidden"
        >
          {/* Decorative background */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 bg-red-50 rounded-full opacity-50" />
          
          <div className="relative z-10">
            <div className="flex flex-col items-center mb-8">
              <div className="bg-red-600 w-16 h-16 rounded-2xl text-white flex items-center justify-center shadow-xl shadow-red-600/20 mb-4">
                <MandarinLogo size={32} />
              </div>
              <h1 className="text-3xl font-bold text-stone-800 tracking-tight">
                {isForgotPassword ? 'Reset Password' : isRegistering ? 'Create Account' : 'Welcome Back'}
              </h1>
              <p className="text-stone-500 font-medium text-center mt-2">
                {isForgotPassword ? 'Enter your email to receive a password reset link.' : isRegistering ? 'Sign up to start learning Mandarin.' : 'Please enter your credentials to access the HSK Tutor platform.'}
              </p>
            </div>

            {isForgotPassword ? (
              <form onSubmit={handleResetPassword} className="space-y-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="email"
                      required
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                    />
                  </div>
                </div>

                {resetError && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl text-sm flex items-start gap-3"
                  >
                    <AlertCircle size={18} className="shrink-0 mt-0.5" />
                    <p className="font-medium">{resetError}</p>
                  </motion.div>
                )}

                {resetMessage && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-emerald-50 border border-emerald-100 text-emerald-600 p-4 rounded-2xl text-sm flex items-start gap-3"
                  >
                    <CheckCircle2 size={18} className="shrink-0 mt-0.5" />
                    <p className="font-medium">{resetMessage}</p>
                  </motion.div>
                )}

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isResetting}
                  type="submit"
                  className="w-full bg-stone-900 text-white rounded-2xl py-4 font-bold shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isResetting ? (
                    <Loader2 size={20} className="animate-spin" />
                  ) : (
                    <span>Get Reset Link</span>
                  )}
                </motion.button>

                <div className="text-center mt-4">
                  <button 
                    type="button"
                    onClick={() => {
                      setIsForgotPassword(false);
                      setResetMessage(null);
                      setResetError(null);
                    }} 
                    className="text-stone-600 font-bold hover:text-red-600 transition-colors"
                  >
                    Sign In
                  </button>
                </div>
              </form>
            ) : !isRegistering ? (
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="email"
                      required
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Password</label>
                  <div className="relative">
                    <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="password"
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <button 
                    type="button"
                    onClick={() => {
                      setResetEmail(loginEmail);
                      setIsForgotPassword(true);
                      setLoginError(null);
                    }}
                    className="text-xs font-bold text-stone-500 hover:text-red-600 transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>

                {loginError && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl text-sm flex items-start gap-3"
                  >
                    <AlertCircle size={18} className="shrink-0 mt-0.5" />
                    <p className="font-medium">{loginError}</p>
                  </motion.div>
                )}

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isLoggingIn}
                  type="submit"
                  className="w-full bg-stone-900 text-white rounded-2xl py-4 font-bold shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isLoggingIn ? (
                    <Loader2 size={20} className="animate-spin" />
                  ) : (
                    <>
                      <LogIn size={20} />
                      <span>Enter Platform</span>
                    </>
                  )}
                </motion.button>
              </form>
            ) : (
              <form onSubmit={handleRegister} className="space-y-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="text"
                      required
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="John Doe"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="email"
                      required
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Password</label>
                  <div className="relative">
                    <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="password"
                      required
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-400 uppercase tracking-widest ml-1">Repeat Password</label>
                  <div className="relative">
                    <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="password"
                      required
                      value={regRepeatPassword}
                      onChange={(e) => setRegRepeatPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:border-red-300 focus:ring-4 focus:ring-red-500/5 transition-all font-medium"
                    />
                  </div>
                </div>

                {regError && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl text-sm flex items-start gap-3"
                  >
                    <AlertCircle size={18} className="shrink-0 mt-0.5" />
                    <p className="font-medium">{regError}</p>
                  </motion.div>
                )}

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isRegisteringUser}
                  type="submit"
                  className="w-full bg-stone-900 text-white rounded-2xl py-4 font-bold shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isRegisteringUser ? (
                    <Loader2 size={20} className="animate-spin" />
                  ) : (
                    <>
                      <User size={20} />
                      <span>Create Account</span>
                    </>
                  )}
                </motion.button>
              </form>
            )}

            <div className="mt-8 pt-6 border-t border-stone-100 text-center">
              <p className="text-sm text-stone-400">
                {!isRegistering ? (
                  <>
                    Don't have an account? <br />
                    <button onClick={() => setIsRegistering(true)} className="text-stone-600 font-bold hover:text-red-600 transition-colors">Sign up here.</button>
                  </>
                ) : (
                  <>
                    Already have an account? <br />
                    <button onClick={() => setIsRegistering(false)} className="text-stone-600 font-bold hover:text-red-600 transition-colors">Sign in here.</button>
                  </>
                )}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  if (currentView === 'vocabulary') {
    return <VocabularyView onBack={handleBackToMenu} />;
  }

  if (currentView === 'progress') {
    return <ProgressView user={user} userRole={userRole} onBack={handleBackToMenu} />;
  }

  if (currentView === 'quiz') {
    return <QuizView user={user} onBack={handleBackToMenu} />;
  }

  if (currentView === 'translation') {
    return <TranslationView onBack={handleBackToMenu} />;
  }

  if (currentView === 'ai-tutor') {
    return (
      <AITutorView 
        hskLevel={hskLevel}
        onHskLevelChange={setHskLevel}
        onBack={handleBackToMenu} 
      />
    );
  }

  if (currentView === 'flashcards') {
    return <FlashcardsView onBack={handleBackToMenu} />;
  }

  if (currentView === 'profile') {
    return <ProfileView user={user} onBack={handleBackToMenu} />;
  }

  if (currentView === 'curriculum') {
    return (
      <CurriculumView 
        hskLevel={hskLevel} 
        onBack={handleBackToMenu} 
        onStartLesson={handleStartLessonFromCurriculum}
      />
    );
  }

  if (currentView === 'writing') {
    return (
      <CharacterWritingView onBack={() => setCurrentView('menu')} />
    );
  }

  if (currentView === 'reading') {
    return (
      <ReadingView onBack={() => setCurrentView('menu')} hskLevel={hskLevel} />
    );
  }

  if (currentView === 'pinyin-chart') {
    return (
      <PinyinChartView onBack={() => setCurrentView('menu')} />
    );
  }

  if (currentView === 'menu') {
    return (
      <div className="min-h-screen bg-[#f5f5f0] text-stone-900 font-sans flex flex-col p-6">
        <div className="max-w-5xl w-full mx-auto">
          <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8 sm:mb-10">
            <div className="flex items-center gap-3 sm:gap-4">
              <div className="bg-red-600 w-10 h-10 sm:w-12 sm:h-12 rounded-xl text-white flex items-center justify-center shadow-lg shadow-red-600/20 shrink-0">
                <MandarinLogo size={20} className="sm:hidden" />
                <MandarinLogo size={24} className="hidden sm:block" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-stone-800 tracking-tight">HSK Tutor</h1>
                <p className="text-[10px] sm:text-xs text-stone-500 font-bold uppercase tracking-widest">Master Mandarin</p>
              </div>
            </div>
            <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto justify-between sm:justify-end">
              {userRole === 'admin' && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-amber-50 text-amber-600 p-2.5 rounded-xl border border-amber-100 shadow-sm hover:bg-amber-100 transition-colors flex items-center gap-2"
                  title="Admin Dashboard"
                >
                  <Shield size={20} />
                  <span className="text-xs font-bold hidden md:inline">Admin</span>
                </motion.button>
              )}

              <HskDropdown 
                value={hskLevel}
                onChange={setHskLevel}
              />

              <motion.button 
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setCurrentView('progress')}
                className="group relative overflow-hidden p-0 bg-white rounded-2xl border border-stone-200 shadow-sm transition-all hover:shadow-md hover:border-red-200"
              >
                <div className="flex items-center gap-2 sm:gap-3 px-3 py-2 sm:px-4 sm:py-2">
                  <div className="bg-red-50 p-1.5 sm:p-2 rounded-xl text-red-600 group-hover:bg-red-600 group-hover:text-white transition-colors">
                    <Trophy size={18} className="sm:hidden" />
                    <Trophy size={20} className="hidden sm:block" />
                  </div>
                  <div className="text-left pr-1 sm:pr-2">
                    <p className="text-[9px] sm:text-[10px] font-bold text-stone-400 uppercase tracking-widest leading-none mb-1 hidden min-[450px]:block">My Progress</p>
                    <div className="flex items-center gap-1.5">
                      <div className="h-1.5 w-10 sm:w-12 bg-stone-100 rounded-full overflow-hidden hidden sm:block">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${progressPercentage}%` }}
                          className="h-full bg-red-500"
                        />
                      </div>
                      <span className="text-xs font-bold text-stone-700">{progressPercentage}%</span>
                    </div>
                  </div>
                </div>
                {/* Shine effect on hover */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:animate-shine pointer-events-none" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setCurrentView('profile')}
                className="bg-stone-100 text-stone-600 p-2.5 rounded-xl border border-stone-200 shadow-sm hover:bg-stone-200 transition-colors"
                title="Profile"
              >
                <User size={20} />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleLogout}
                className="bg-stone-100 text-stone-600 p-2.5 rounded-xl border border-stone-200 shadow-sm hover:bg-stone-200 transition-colors"
                title="Logout"
              >
                <LogOut size={20} />
              </motion.button>
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Main Action: Curriculum */}
            <button 
              onClick={() => setCurrentView('curriculum')}
              className="md:col-span-2 md:row-span-2 bg-stone-900 p-8 rounded-[2.5rem] shadow-xl shadow-stone-900/20 flex flex-col justify-between text-left hover:bg-stone-800 transition-all group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
                <BookOpen size={120} />
              </div>
              <div className="bg-white/20 w-14 h-14 rounded-2xl flex items-center justify-center text-white mb-4">
                <BookOpen size={32} />
              </div>
              <div>
                <h3 className="text-3xl font-bold text-white mb-2">Learning Path</h3>
                <p className="text-stone-300 text-lg">Structured modules and lessons for {hskLevel}.</p>
              </div>
            </button>

            {/* Quick Practice: Start Lesson */}
            <button 
              onClick={() => {
                setSelectedLesson(null);
                setCurrentView('lesson');
              }}
              className="md:col-span-2 bg-red-600 p-6 rounded-[2rem] shadow-lg shadow-red-600/20 flex items-center gap-6 text-left hover:bg-red-700 transition-all group"
            >
              <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center text-white shrink-0">
                <Mic size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Quick Practice</h3>
                <p className="text-red-100 text-sm">Jump straight into AI conversation.</p>
              </div>
            </button>

            {/* AI Tutor Chat */}
            <button 
              onClick={() => setCurrentView('ai-tutor')}
              className="md:col-span-2 bg-indigo-600 p-6 rounded-[2rem] shadow-lg shadow-indigo-600/20 flex items-center gap-6 text-left hover:bg-indigo-700 transition-all group"
            >
              <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center text-white shrink-0">
                <MessageSquare size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">AI Tutor Chat</h3>
                <p className="text-indigo-100 text-sm">Ask questions about grammar & culture.</p>
              </div>
            </button>

            {/* Flashcards */}
            <button 
              onClick={() => setCurrentView('flashcards')}
              className="bg-amber-500 p-6 rounded-[2rem] shadow-lg shadow-amber-500/20 flex flex-col justify-between text-left hover:bg-amber-600 transition-all group"
            >
              <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4">
                <RefreshCw size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Flashcards</h3>
                <p className="text-amber-50 text-xs">Quick vocabulary review.</p>
              </div>
            </button>

            {/* Vocabulary Quiz */}
            <button 
              onClick={() => setCurrentView('quiz')}
              className="bg-emerald-500 p-6 rounded-[2rem] shadow-lg shadow-emerald-500/20 flex flex-col justify-between text-left hover:bg-emerald-600 transition-all group"
            >
              <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4">
                <HelpCircle size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Vocab Quiz</h3>
                <p className="text-emerald-50 text-xs">Test your word knowledge.</p>
              </div>
            </button>

            {/* Sentence Builder */}
            <button 
              onClick={() => setCurrentView('sentence-builder')}
              className="md:col-span-2 bg-purple-600 p-6 rounded-[2rem] shadow-lg shadow-purple-600/20 flex items-center gap-6 text-left hover:bg-purple-700 transition-all group"
            >
              <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center text-white shrink-0">
                <Languages size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Sentence Builder</h3>
                <p className="text-purple-100 text-sm">Master Chinese word order and syntax.</p>
              </div>
            </button>

            {/* Vocabulary List */}
            <button 
              onClick={() => setCurrentView('vocabulary')}
              className="bg-yellow-400 p-6 rounded-[2rem] shadow-lg shadow-yellow-400/20 flex flex-col justify-between text-left hover:bg-yellow-500 transition-all group"
            >
              <div className="bg-black/10 w-12 h-12 rounded-xl flex items-center justify-center text-stone-900 mb-4">
                <BookOpen size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-stone-900">Vocab List</h3>
                <p className="text-stone-800/60 text-xs font-medium">Browse all HSK words.</p>
              </div>
            </button>

            {/* Character Writing */}
            <button 
              onClick={() => setCurrentView('writing')}
              className="bg-red-500 p-6 rounded-[2rem] shadow-lg shadow-red-500/20 flex flex-col justify-between text-left hover:bg-red-600 transition-all group"
            >
              <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4">
                <Pencil size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Writing</h3>
                <p className="text-red-50 text-xs">Practice stroke order.</p>
              </div>
            </button>

            {/* Reading Practice */}
            <button 
              onClick={() => setCurrentView('reading')}
              className="bg-emerald-600 p-6 rounded-[2rem] shadow-lg shadow-emerald-600/20 flex flex-col justify-between text-left hover:bg-emerald-700 transition-all group"
            >
              <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4">
                <BookOpen size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Reading</h3>
                <p className="text-emerald-50 text-xs">AI-generated stories.</p>
              </div>
            </button>

            {/* Pinyin Chart */}
            <button 
              onClick={() => setCurrentView('pinyin-chart')}
              className="bg-blue-500 p-6 rounded-[2rem] shadow-lg shadow-blue-500/20 flex flex-col justify-between text-left hover:bg-blue-600 transition-all group"
            >
              <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4">
                <Volume2 size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Pinyin</h3>
                <p className="text-blue-50 text-xs">Master pronunciation.</p>
              </div>
            </button>

            {/* Grammar Guide */}
            <button 
              onClick={() => setCurrentView('grammar')}
              className="bg-blue-600 p-6 rounded-[2rem] shadow-lg shadow-blue-600/20 flex flex-col justify-between text-left hover:bg-blue-700 transition-all group"
            >
              <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4">
                <Activity size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Grammar</h3>
                <p className="text-blue-100 text-xs">HSK sentence structures.</p>
              </div>
            </button>
          </div>

          <motion.div 
            whileHover={{ scale: 1.02, y: -4 }}
            className="mt-10 p-6 bg-white rounded-3xl border border-stone-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 group transition-all hover:shadow-xl hover:border-red-100 relative overflow-hidden"
          >
            {/* Background decoration */}
            <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-red-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            
            <div className="flex items-center gap-4 relative z-10">
              <div className="bg-red-50 p-3 rounded-2xl text-red-600 group-hover:bg-red-600 group-hover:text-white transition-colors duration-300">
                <Sparkles size={24} />
              </div>
              <div>
                <h4 className="font-bold text-stone-800">Try our advanced translator</h4>
                <p className="text-sm text-stone-500">Practice speaking and listening with real-time AI translation.</p>
              </div>
            </div>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentView('translation')}
              className="px-8 py-3 bg-stone-900 text-white rounded-2xl font-bold hover:bg-stone-800 transition-colors shadow-lg shadow-stone-900/10 relative z-10"
            >
              Open Translator
            </motion.button>
          </motion.div>
        </div>
      </div>
    );
  }

  if (currentView === 'grammar') {
    return (
      <div className="min-h-screen bg-[#f5f5f0] flex flex-col">
        <header className="bg-white border-b border-stone-200 py-4 px-6 shadow-sm sticky top-0 z-40">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button 
                onClick={handleBackToMenu}
                className="p-2 -ml-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-full transition-colors"
                aria-label="Back to Menu"
              >
                <ArrowLeft size={24} />
              </button>
              <div className="flex items-center gap-3">
                <div className="bg-indigo-600 p-2 rounded-xl text-white hidden sm:block">
                  <BookOpen size={20} />
                </div>
                <div>
                  <h1 className="text-lg font-bold text-stone-800 tracking-tight">Grammar Guide</h1>
                  <p className="text-xs text-stone-500 font-medium uppercase tracking-wider">Sentence Structures</p>
                </div>
              </div>
            </div>
          </div>
        </header>
        <main className="flex-1 max-w-4xl w-full mx-auto p-6">
          <div className="bg-white rounded-3xl shadow-sm border border-stone-200 overflow-hidden h-[calc(100vh-120px)]">
            <GrammarView level={hskLevel} onLevelChange={setHskLevel} />
          </div>
        </main>
      </div>
    );
  }

  if (currentView === 'sentence-builder') {
    return <SentenceBuilderView user={user} onBack={handleBackToMenu} />;
  }

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-stone-900 font-sans flex flex-col relative">
      {/* Persistent HSK Level Badge */}
      <div className="fixed bottom-6 right-6 z-50">
        <motion.div 
          whileHover={{ scale: 1.1, x: -5 }}
          whileTap={{ scale: 0.9 }}
          className="bg-white/90 backdrop-blur-md px-5 py-3 rounded-2xl shadow-xl border border-stone-200 flex items-center gap-3 cursor-help group transition-all hover:border-red-300 hover:shadow-red-500/10"
        >
          <div className="bg-red-100 p-2 rounded-xl group-hover:bg-red-600 group-hover:text-white transition-colors duration-300">
            <BookOpen size={20} className="text-red-600 group-hover:text-white" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-stone-400 uppercase tracking-widest leading-none mb-1 group-hover:text-red-400 transition-colors">Current Focus</p>
            <p className="font-bold text-stone-800 leading-none text-lg">{hskLevel}</p>
          </div>
          
          {/* Decorative element */}
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white shadow-sm animate-pulse" />
        </motion.div>
      </div>

      {/* Header */}
      <header className="bg-white border-b border-stone-200 py-3 sm:py-4 px-4 sm:px-6 shadow-sm z-40 sticky top-0">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-4">
            <button 
              onClick={handleBackToMenu}
              className="p-1.5 sm:p-2 -ml-1 sm:-ml-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-full transition-colors"
              aria-label="Back to Menu"
            >
              <ArrowLeft size={20} className="sm:hidden" />
              <ArrowLeft size={24} className="hidden sm:block" />
            </button>
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="bg-red-600 p-1.5 sm:p-2 rounded-xl text-white hidden min-[400px]:block">
                <MandarinLogo size={16} className="sm:hidden" />
                <MandarinLogo size={20} className="hidden sm:block" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-bold text-stone-800 tracking-tight leading-tight">
                  {selectedLesson ? selectedLesson.title : 'Practice Session'}
                </h1>
                <p className="text-[10px] text-stone-500 font-medium uppercase tracking-wider hidden sm:block">
                  {selectedLesson ? 'Curriculum Practice' : 'HSK Preparation'}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <HskDropdown 
              value={hskLevel}
              onChange={setHskLevel}
              disabled={isConnected || isConnecting}
            />
            {isConnected && (
              <div className="flex items-center gap-2 text-[10px] sm:text-sm font-medium text-emerald-600 bg-emerald-50 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full border border-emerald-100">
                <span className="relative flex h-2 w-2 sm:h-2.5 sm:w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 sm:h-2.5 sm:w-2.5 bg-emerald-500"></span>
                </span>
                <span className="hidden min-[400px]:inline">Live</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-6 flex flex-col gap-6">
        
        {/* Status / Hero Section */}
        <div className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 flex flex-col items-center justify-center text-center relative overflow-hidden">
          
          {/* Decorative background elements */}
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-5">
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-red-600 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-amber-500 rounded-full blur-3xl"></div>
          </div>

          <div className="relative z-10 flex flex-col items-center">
            <div className="mb-6">
              <span className="bg-red-50 text-red-600 text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wider border border-red-100 shadow-sm">
                Current Focus: {hskLevel}
              </span>
            </div>
            
            <div className="mb-6 relative">
              <motion.button
                onClick={toggleConnection}
                disabled={isConnecting}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-colors duration-300 ${
                  isConnected 
                    ? 'bg-red-600 text-white shadow-red-600/30' 
                    : 'bg-stone-800 text-white shadow-stone-800/30'
                }`}
              >
                {isConnecting ? (
                  <Loader2 size={32} className="animate-spin" />
                ) : isConnected ? (
                  <Mic size={36} />
                ) : (
                  <MicOff size={36} />
                )}
              </motion.button>
              
              {/* Model Speaking indicator rings */}
              <AnimatePresence>
                {isConnected && isModelSpeaking && (
                  <>
                    <motion.div
                      initial={{ opacity: 0, scale: 1 }}
                      animate={{ opacity: [0, 0.3, 0], scale: [1, 1.5, 2] }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
                      className="absolute inset-0 rounded-full bg-red-500 pointer-events-none"
                    />
                    <motion.div
                      initial={{ opacity: 0, scale: 1 }}
                      animate={{ opacity: [0, 0.3, 0], scale: [1, 1.5, 2] }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut", delay: 0.5 }}
                      className="absolute inset-0 rounded-full bg-red-500 pointer-events-none"
                    />
                  </>
                )}
              </AnimatePresence>
            </div>

            <h2 className="text-2xl font-semibold mb-2">
              {isConnected 
                ? (isModelSpeaking ? "Tutor is speaking..." : isUserSpeaking ? "Listening to you..." : "Waiting for you to speak...") 
                : selectedLesson 
                  ? `Start Lesson: ${selectedLesson.title}` 
                  : `Start Your ${hskLevel} Lesson`}
            </h2>
            
            {/* User VAD Indicator */}
            {isConnected && (
              <div className="flex flex-col items-center justify-center gap-4 mt-2 mb-6">
                <div className="h-8 flex items-center justify-center">
                  {isUserSpeaking ? (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-3 text-emerald-700 bg-emerald-50 px-4 py-1.5 rounded-full text-sm font-bold border border-emerald-200 shadow-sm"
                    >
                      <div className="flex gap-1 items-center h-4">
                        <motion.div animate={{ height: ["4px", "12px", "4px"] }} transition={{ duration: 0.5, repeat: Infinity, ease: "easeInOut" }} className="w-1 bg-emerald-500 rounded-full" />
                        <motion.div animate={{ height: ["4px", "16px", "4px"] }} transition={{ duration: 0.6, repeat: Infinity, ease: "easeInOut", delay: 0.1 }} className="w-1 bg-emerald-500 rounded-full" />
                        <motion.div animate={{ height: ["4px", "10px", "4px"] }} transition={{ duration: 0.4, repeat: Infinity, ease: "easeInOut", delay: 0.2 }} className="w-1 bg-emerald-500 rounded-full" />
                      </div>
                      Listening...
                    </motion.div>
                  ) : (
                    <div className="flex items-center gap-2 text-stone-400 px-4 py-1.5 rounded-full text-sm font-medium">
                      <MicOff size={16} />
                      Waiting for voice...
                    </div>
                  )}
                </div>
                
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <motion.button
                    onClick={requestTranslation}
                    disabled={isModelSpeaking}
                    whileHover={{ scale: isModelSpeaking ? 1 : 1.05 }}
                    whileTap={{ scale: isModelSpeaking ? 1 : 0.95 }}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-colors border shadow-sm ${
                      isModelSpeaking 
                        ? 'bg-stone-100 text-stone-400 border-stone-200 cursor-not-allowed' 
                        : 'bg-white hover:bg-stone-50 text-stone-700 border-stone-200'
                    }`}
                  >
                    <Languages size={18} className={isModelSpeaking ? 'text-stone-400' : 'text-red-500'} />
                    Translate Next Phrase
                  </motion.button>
                  <motion.button
                    onClick={requestPronunciationPractice}
                    disabled={isModelSpeaking}
                    whileHover={{ scale: isModelSpeaking ? 1 : 1.05 }}
                    whileTap={{ scale: isModelSpeaking ? 1 : 0.95 }}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-colors border shadow-sm ${
                      isModelSpeaking 
                        ? 'bg-stone-100 text-stone-400 border-stone-200 cursor-not-allowed' 
                        : 'bg-white hover:bg-stone-50 text-stone-700 border-stone-200'
                    }`}
                  >
                    <Volume2 size={18} className={isModelSpeaking ? 'text-stone-400' : 'text-emerald-500'} />
                    Practice Pronunciation
                  </motion.button>
                </div>
              </div>
            )}

            {!isConnected && (
              <p className="text-stone-500 max-w-md mx-auto mb-8">
                Connect to practice your Mandarin pronunciation, vocabulary, and daily conversations.
              </p>
            )}

            {error && (
              <div className="bg-red-50 text-red-600 px-4 py-3 rounded-xl text-sm font-medium mb-4 border border-red-100">
                {error}
              </div>
            )}
          </div>
        </div>

        {/* Features / Tips (Shown when disconnected) */}
        {!isConnected && messages.length === 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <div className="bg-stone-100 w-10 h-10 rounded-full flex items-center justify-center mb-4 text-stone-700">
                <BookOpen size={20} />
              </div>
              <h3 className="font-semibold mb-2">Targeted Level</h3>
              <p className="text-sm text-stone-500">Currently focusing on {hskLevel} vocabulary and grammar structures.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <div className="bg-stone-100 w-10 h-10 rounded-full flex items-center justify-center mb-4 text-stone-700">
                <MessageSquare size={20} />
              </div>
              <h3 className="font-semibold mb-2">Interactive Chat</h3>
              <p className="text-sm text-stone-500">The tutor will keep responses short and ask questions to keep you talking.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
              <div className="bg-stone-100 w-10 h-10 rounded-full flex items-center justify-center mb-4 text-stone-700">
                <Volume2 size={20} />
              </div>
              <h3 className="font-semibold mb-2">Pronunciation</h3>
              <p className="text-sm text-stone-500">Get instant feedback on your tones and pronunciation accuracy.</p>
            </div>
          </div>
        )}

        {/* Transcript Area (Shown when there are messages) */}
        {messages.length > 0 && (
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 flex-1 flex flex-col min-h-[300px]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-stone-400 uppercase tracking-wider flex items-center gap-2">
                <MessageSquare size={16} />
                Session Transcript
              </h3>
              <button
                onClick={clearHistory}
                className="text-xs font-semibold text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-full transition-colors"
              >
                Clear History
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-4 pr-2">
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-[85%] rounded-2xl px-5 py-4 shadow-sm ${
                      msg.role === 'user' 
                        ? 'bg-stone-800 text-white rounded-tr-sm' 
                        : 'bg-stone-100 text-stone-800 rounded-tl-sm border border-stone-200'
                    }`}
                  >
                    {msg.structured ? (
                      <div className="space-y-2">
                        {msg.structured.chinese && (
                          <p className={`text-xl font-medium ${msg.role === 'user' ? 'text-white' : 'text-stone-900'}`}>
                            {msg.structured.chinese}
                          </p>
                        )}
                        {msg.structured.pinyin && (
                          <p className={`text-sm ${msg.role === 'user' ? 'text-stone-300' : 'text-stone-500'}`}>
                            {msg.structured.pinyin}
                          </p>
                        )}
                        {msg.structured.english && (
                          <p className={`text-[15px] pt-2 mt-2 border-t ${msg.role === 'user' ? 'border-stone-700 text-stone-200' : 'border-stone-200 text-stone-600'}`}>
                            {msg.structured.english}
                          </p>
                        )}
                      </div>
                    ) : (
                      <p className="text-[15px] leading-relaxed whitespace-pre-wrap">{msg.text.replace(/\[(You|Tutor)\]\n/, '')}</p>
                    )}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
